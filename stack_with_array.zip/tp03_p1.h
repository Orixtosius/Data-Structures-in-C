#ifndef LIB_H_ 
#define LIB_H_
#define size 3
#include <stdio.h>
#include <stdlib.h>

struct stack
{
    int value[size];
    int top;
};
typedef struct stack ST;
ST s;

void push(int data);
int pop();
void show();
#endif
#include "tp03_p1.h"

void push(int data)
{
    if(s.top>=size)
    {
        printf("Cette operation est termine a cause de depassement de la capasite!\n");
    }
    else
    {
        s.value[s.top] = data;
        s.top++;
    }
}

int pop()
{
    int res;
    if(s.top<1)
    {
        printf("Cette operation est termine car la pile est vite!\n");
        exit(1); 
    }
    else
    {
        s.top--;
        return s.value[s.top];
    }
}
void show()
{
    if(s.top == 0)
    {
        printf("Il n'y a pas d'element!\n");        
    }

   else 
   {
      for (int i =0; i<s.top; i++)
      {
          printf("Element %d est : %d\n", i+1, s.value[i]);
      }
   }
         
}
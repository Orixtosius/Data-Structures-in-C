#include "tp03_p4.h"

struct node *front= NULL;
struct node *rear = NULL ;

void enqueue(int data)
{
    struct node *temp;
    temp = (struct node*)malloc(sizeof(struct node));
    temp->value = data;
    temp->next = NULL;
    if(front == NULL)
    {
        front = rear = temp;
    }
    else
    {
        rear->next = temp;
        rear = temp;
    }
    
}

int dequeue()
{
    if(front == NULL)
    {
        printf("Cette operation est termine car la pile est vite!\n");
        exit(1); 
    }
    else
    {
        struct node *temp = front;
        int res = temp->value;
        front = front->next;
        free(temp);
        return res;
    }
}

void print()
{
    if(front == NULL)
    {
        printf("Cette file est vite!\n");
    }
    else
    {
        struct node *temp = front;
        while(temp->next != NULL)
        {
            printf("Les elements sont:\n%d\n",temp->value);
            temp = temp -> next;
        }
        printf("%d \n",temp->value);
    }
    
}
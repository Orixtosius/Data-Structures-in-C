#ifndef LIB_H_
#define LIB_H_
#include <stdio.h>
#include <stdlib.h>

struct node
{
    int value;
    struct node *next;
};

void enqueue(int data);
int dequeue();
void print();
#endif
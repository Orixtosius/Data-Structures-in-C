#include "tp03_p2.h"

void push(int data)
{
    ST *new;
    new = malloc(sizeof(ST));
    new->value = data;
    new->next = head;
    head = new;
}

int pop()
{
    int poppedValue;
    if(head==NULL)
    {
        printf("Cette operation est termine car la pile est vite!\n");
        exit(1); 
    }
    else
    {
        ST *temp;
        temp = head;
        poppedValue = temp->value;
        head = head->next;
        free(temp);
    }
    return poppedValue;

}

void print()
{
    if(head==NULL)
    {
        printf("Cette pile est vite!\n");
    }
    else
    {
        while(head!=NULL)
        {
            printf("Les element de la pile est\n%d\n",head->value);
            head=head->next;
        }
      
        
    }

}

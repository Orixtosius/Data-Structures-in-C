#ifndef LIB_H_
#define LIB_H_
#include <stdio.h>
#include <stdlib.h>
struct stack
{
    int value;
    struct stack *next;
};
typedef struct stack ST;
ST *head;
void push(int data);
int pop();
void print();
#endif
#include "tp03_p2.h"

int main()
{
    head = NULL;
    int programme = 1;
    int button;
    int element;
    while(programme)
    {
        printf("Choisissez ce que vous aimeriez faire ? \n1 pour Empiler\n2 pour Depiler\n3 pour Afficher\n4 pour Quitter\n");
        scanf("%d", &button);        
        switch(button)
        {
            case 1:
                printf("Choisissez ce que vous aimeriez ajouter\n");
                scanf("%d",&element);
                push(element);
                break;
            case 2:
                element = pop();
                printf("Element depile est %d\n", element);
                break;
            case 3:
                print();
                break;
            case 4:
                exit(0);
        }
        printf("Voulez-vous quitter? \n0 pour Oui, 1 pour Non\n");
        scanf("%d",&programme);
    }

    return 0;
}
